#!/bin/sh
# File:				update.sh	
# Provides:         
# Description:      update zImage&rootfs under dir1/dir2/...
# Author:			aj

play_recover_tip()
{
	echo "/usr/share/anyka_recover_device.mp3" > /tmp/alarm_audio_list
	killall -12 anyka_ipc
	sleep 3
}

play_recover_tip

cp /etc/jffs2/bake/anyka_cfg.ini /etc/jffs2/anyka_cfg.ini
cp /etc/jffs2/bake/app_ker_update_client_ip.ini /etc/jffs2/app_ker_update_client_ip.ini
cp /etc/jffs2/bake/hostapd.conf /etc/jffs2/hostapd.conf
cp /etc/jffs2/bake/resolv.conf /etc/jffs2/resolv.conf
cp /etc/jffs2/bake/wpa_supplicant.conf /etc/jffs2/wpa_supplicant.conf


