#!/bin/sh
# File:				update.sh	
# Provides:         
# Description:      update zImage&rootfs under dir1/dir2/...
# Author:			xc

VAR1="zImage"
VAR2="root.sqsh4"
VAR3="root.jffs2"

DIR1="/mnt"
DIR2="/tmp"

update_voice_tip(){
	echo "play update voice tips"
	echo "/usr/share/anyka_update_device.mp3" > /tmp/alarm_audio_list
	killall -12 anyka_ipc
	sleep 3
}

update_kernel()
{
		echo "check ${VAR1}............................."
		
        for dir in ${DIR1} ${DIR2}
        do
            if [ -e ${dir}/${VAR1} ] 
    		then
    		    echo "update ${VAR1} under ${dir}...."
    		    /usr/bin/updater local K=${dir}/${VAR1}
    		    break
    	    fi	
        done
}

update_squash()
{		
		echo "check ${VAR2}.........................."

        for dir in ${DIR1} ${DIR2}
        do
            if [ -e ${dir}/${VAR2} ] 
    		then
    		    echo "update ${VAR2} under ${dir}...."
    		    /usr/bin/updater local MTD1=${dir}/${VAR2}
    		    break
    	    fi	
        done
}

update_jffs2()
{
		echo "check ${VAR3}........................"

        for dir in ${DIR1} ${DIR2}
        do
            if [ -e ${dir}/${VAR3} ] 
    		then
    		    echo "update ${VAR3} under ${dir}...."
    		    /usr/bin/updater local MTD2=${dir}/${VAR3}
    		    break
    	    fi	
        done
}


#
# main:
#
echo "stop system service before update....."
killall -15 syslogd
killall -15 klogd
killall -15 tcpsvd

# play update vioce tip
update_voice_tip

# send signal to stop watchdog
killall -12 daemon 
sleep 5
# kill apps
killall -15 daemon
#killall -15 discovery
killall -15 anyka_ipc
killall -15 net_manage.sh
killall -9 smartlink_wifi.sh
killall -15 wifi_run.sh
/etc/init.d/wifi_manage.sh stop
/etc/init.d/wifi_manage.sh uninstall
killall -9 smartlink

echo "############ please wait a moment. And don't remove TFcard or power-off #############"

#led blink
/etc/init.d/led.sh blink 50 50

update_kernel
update_jffs2
update_squash

echo "############ update finished, reboot now #############"

sleep 3
reboot -f

exit 0
