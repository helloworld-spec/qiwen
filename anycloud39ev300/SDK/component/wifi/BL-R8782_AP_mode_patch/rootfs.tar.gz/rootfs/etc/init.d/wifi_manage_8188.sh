#! /bin/sh
### BEGIN INIT INFO
# File:				wifi_manage.sh	
# Provides:         start wifi station and ap
# Required-Start:   $
# Required-Stop:
# Default-Start:     
# Default-Stop:
# Short-Description:start wifi run at station or softAP
# Author:			
# Email: 			
# Date:				2012-8-8
### END INIT INFO

PATH=$PATH:/bin:/sbin:/usr/bin:/usr/sbin
MODE=$1
cfgfile="/etc/jffs2/anyka_cfg.ini"

usage()
{
	echo "Usage: $0 install | uninstall | start | stop | restart | reset"
}


wifi_remove()
{
	#rm sdio wifi driver
	#rmmod 8189es

	#rm usb wifi driver(default)
	rmmod 8188eu
	rmmod otg-hs
}

wifi_setup()
{
	/etc/init.d/led.sh blink 1000 200
	
	#install usb wifi driver(default)
	insmod /root/otg-hs.ko
	insmod /root/8188eu.ko

	#install sdio wifi driver
	#insmod /root/8189es.ko
}


wifi_stop()
{	
	/etc/init.d/wifi_station.sh stop
	/etc/init.d/wifi_ap.sh stop
}


wifi_restart()
{
	echo "wifi restart and update wifi info"
	wifi_station_stop
	wifi_ap_stop
	wifi_station_start
	wifi_ap_start
}


wifi_reset()
{
	echo "wifi reset and update wifi info"
	wifi_stop
	/etc/init.d/wifi_run.sh &
}


case "$MODE" in
	install)
		wifi_setup
		;;		
	uninstall)
		wifi_remove
		;;
	start)
		/etc/init.d/wifi_run.sh &
		;;
	stop)
		killall -15 wifi_run.sh
		wifi_stop
		;;
	restart)
		wifi_restart
		;;
	reset)
		sleep 2
		killall -15 wifi_run.sh
		wifi_reset
		;;
	*)
		usage
		;;
esac
exit 0

