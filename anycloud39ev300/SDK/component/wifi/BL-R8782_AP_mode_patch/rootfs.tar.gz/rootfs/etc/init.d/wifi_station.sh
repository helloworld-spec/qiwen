#! /bin/sh
### BEGIN INIT INFO
# File:				wifi_ap.sh	
# Provides:         wifi ap start and stop
# Required-Start:   $
# Required-Stop:
# Default-Start:     
# Default-Stop:
# Short-Description:start wifi run at station or softAP
# Author:			
# Email: 			
# Date:				2014-12-19
### END INIT INFO

PATH=$PATH:/bin:/sbin:/usr/bin:/usr/sbin
MODE=$1
cfgfile="/etc/jffs2/anyka_cfg.ini"
encrytion_type=

usage()
{
	echo "Usage: $0 start | stop | connect"
}

getinfo(){

	local _val=$1

	wpa_cli -iwlan0 scan

	while true
	do
		ssid=`awk 'BEGIN {FS="="}/\[wireless\]/{a=1} a==1&&
			$1~/^ssid/{gsub(/\"/,"",$2);gsub(/\;.*/, "", $2);
		gsub(/^[[:blank:]]*/,"",$2);print $2}' $cfgfile`

		if [ "$ssid" != "" ];then
			ret=`wpa_cli -iwlan0 scan_results | grep $ssid`

			if [ "$ret" != "" ];then
			{
				enc_type=`echo $ret | grep WPA`
				if [ "`echo $ret | grep WPA`" != "" ];then
					eval $_val=wpa
					break
				elif [ "`echo $ret | grep WEP`" != "" ];then
					eval $_val=wep
					break
				else
					eval $_val=open
					break
				fi
			}
			fi

		else
			sleep 2
		fi

	done
}

wifi_station_start()
{
	wpa_supplicant -B -iwlan0 -Dwext -c /etc/jffs2/wpa_supplicant.conf
}

wifi_station_connect()
{
	echo "connect wifi station......"
	
	ssid=`awk 'BEGIN {FS="="}/\[wireless\]/{a=1} a==1&&$1~/^ssid/{gsub(/\"/,"",$2);gsub(/\;.*/, "", $2);gsub(/^[[:blank:]]*/,"",$2);print $2}' $cfgfile`
	mode=`awk 'BEGIN {FS="="}/\[wireless\]/{a=1} a==1&&$1~/^mode/{gsub(/\"/,"",$2);gsub(/\;.*/, "", $2);gsub(/^[[:blank:]]*/,"",$2);print $2}' $cfgfile`
	security=`awk 'BEGIN {FS="="}/\[wireless\]/{a=1} a==1&&$1~/^security/{gsub(/\"/,"",$2);gsub(/\;.*/, "", $2);gsub(/^[[:blank:]]*/,"",$2);print $2}' $cfgfile`
	password=`awk 'BEGIN {FS="="}/\[wireless\]/{a=1} a==1&&$1~/^password/{gsub(/\"/,"",$2);gsub(/\;.*/, "", $2);gsub(/^[[:blank:]]*/,"",$2);print $2}' $cfgfile`
	ssid=`echo "$ssid"|awk '{print $1}'`
	password=`echo "$password"|awk '{print $1}'`

	if [ "$mode" = "Ad-Hoc" ] || [ "`echo $mode|grep -i "hoc"`" != "" ]
	then
		security=adhoc
	else
		getinfo security
	fi
	
	echo "security=$security ssid=$ssid password=$password"
	/etc/init.d/station_connect.sh $security "$ssid" "$password" 
	
}

wifi_station_stop()
{
	echo "stop wifi station......"
	killall wpa_supplicant
	killall udhcpc
	ifconfig wlan0 down
}


case "$MODE" in
	start)
		wifi_station_start
		;;
	stop)
		wifi_station_stop
		;;
	connect)
		wifi_station_connect
		;;
	*)
		usage
		;;
esac
exit 0


