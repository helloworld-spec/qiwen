/* Copyright (c) 2008 -2014 Espressif System.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */
#ifndef _ESP_PATH_H_
#define _ESP_PATH_H_
#define FWPATH "/mnt/8089"
//module_param_string(fwpath, fwpath, sizeof(fwpath), 0644);

#endif /* _ESP_PATH_H_ */
